package com.enterprises.enterprises;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnterprisesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnterprisesApplication.class, args);
	}

}
